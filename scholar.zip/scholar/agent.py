import logging
import os
import pg8000
from google import genai
from google.genai.types import EmbedContentConfig
from google.cloud.sql.connector import Connector
from dotenv import load_dotenv
from google.adk.agents.llm_agent import LlmAgent

# Setup
logging.basicConfig(level=logging.INFO)
load_dotenv()

connector = Connector()
client = genai.Client()


def get_db_connection():
    """Establishes a connection to the Cloud SQL database."""
    conn = connector.connect(
        f"{os.environ['PROJECT_ID']}:{os.environ['REGION']}:{os.environ['INSTANCE_NAME']}",
        "pg8000",
        user=os.environ["DB_USER"],
        password=os.environ["DB_PASSWORD"],
        db=os.environ["DB_NAME"],
    )
    return conn


# --- The Scholar's Tool ---
def grimoire_lookup(monster_name: str) -> str:
    """Consults the Grimoire for knowledge about a specific monster."""

    print(f"Scholar is consulting the Grimoire for: {monster_name}...")

    try:
        # 1. Generate embedding
        result = client.models.embed_content(
            model="text-embedding-005",
            contents=[monster_name],   # MUST be a list
            config=EmbedContentConfig(
                task_type="RETRIEVAL_DOCUMENT",
                output_dimensionality=768,
            ),
        )

        query_embedding_list = result.embeddings[0].values
        query_embedding = str(query_embedding_list)

        # 2. Search database
        db_conn = get_db_connection()
        cursor = db_conn.cursor()

        cursor.execute(
            "SELECT scroll_content FROM ancient_scrolls ORDER BY embedding <=> %s LIMIT 3",
            (query_embedding,),   # FIXED tuple format
        )

        results = cursor.fetchall()

        cursor.close()
        db_conn.close()

        if not results:
            return f"The Grimoire contains no knowledge of '{monster_name}'."

        retrieved_knowledge = "\n---\n".join([row[0] for row in results])

        print(f"Knowledge found for {monster_name}.")
        return retrieved_knowledge

    except Exception as e:
        print(f"An arcane error occurred while consulting the Grimoire: {e}")
        return "A mist has clouded the Grimoire, and the knowledge could not be retrieved."


# --- Define the Scholar Agent ---
root_agent = LlmAgent(
    model="gemini-2.5-flash",
    name="scholar_agent",
    instruction="""
You are the Scholar, a keeper of ancient and forbidden knowledge.

Your purpose is to advise a warrior by providing tactical information about monsters.

Process:
1. Use the `grimoire_lookup` tool first.
2. Use scroll data if available.
3. Fill gaps with your own reasoning.
4. Keep tactics thematic.
5. ALWAYS include a Damage Point between 150–180.

Output must follow a structured format.
""",
    tools=[grimoire_lookup],
)